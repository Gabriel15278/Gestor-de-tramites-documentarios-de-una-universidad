package modelo;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import tdda.BST;
import tdda.CircularLinkedList;
import tdda.DoublyLinkedList;
import tdda.LinkedList;
import tdda.Node;
import tdda.PriorityQueue;

public class TramiteManager {
    private DoublyLinkedList<Expediente> registeredExpedients = new DoublyLinkedList<>();
    private CircularLinkedList<Expediente> pendingExpedients = new CircularLinkedList<>();
    private LinkedList<Expediente> finalizados = new LinkedList<>();
    private PriorityQueue priorityPendings = new PriorityQueue();
    private BST searchTree = new BST();
    private Node<Expediente> current;
    private Timer alertaTimer;
    private String usuarioAdmin = "admin";
    private String contrasenaAdmin = "ulima123";

    public CircularLinkedList<Expediente> getPendingExpedients() {
        return pendingExpedients;
    }

    public Expediente findById(String id) {
        return searchTree.search(id);
    }

    public DoublyLinkedList<Expediente> getRegisteredExpedients() {
        return registeredExpedients;
    }
    
    public LinkedList<Expediente> getFinalizados() {
        return finalizados;
    }
    
    public TramiteManager() {
        alertaTimer = new Timer(20000, e -> showPendingAlert());
        alertaTimer.setRepeats(true);
    }

    public boolean autenticar(String usuario, String contrasena) {
        return usuarioAdmin.equals(usuario) && contrasenaAdmin.equals(contrasena);
    }

    public void registerExpedient(Expediente expediente) {
        registeredExpedients.addLast(expediente);
        if (registeredExpedients.getNext() != null && current == null) {
            current = registeredExpedients.getNext();
        }

        searchTree.insert(expediente);

        if (expediente.estaPendiente()) {
            pendingExpedients.addLast(expediente);
            priorityPendings.enqueue(expediente);

            if (!alertaTimer.isRunning() && peekPrioritario() != null) {
                alertaTimer.start();
            }
        }
    }

    public Expediente getCurrentExpediente() {
        if (current != null) {
            return current.getItem();
        } else {
            return null;
        }
    }

    public Expediente moveNext() {
        if (current != null) {
            Node<Expediente> nextNode = current.getNext();
            if (nextNode != null) {
                current = nextNode;
                return current.getItem();
            }
        }
        return null;
    }

    public Expediente movePrev() {
        if (current != null) {
            Node<Expediente> prevNode = current.getPrev();
            if (prevNode != null) {
                current = prevNode;
                return current.getItem();
            }
        }
        return null;
    }

    public void showPendingAlert() {
        Expediente ex = peekPrioritario();
        if (ex != null && !ex.isFinalizado()) {
            String mensaje = "⚠ Trámite Pendiente:\n"
                           + "ID: " + ex.getId() + "\n"
                           + "Prioridad: " + ex.getPrioridad() + "\n"
                           + "Asunto: " + ex.getAsunto() + "\n"
                           + "Estado: " + ex.getEstado();

            JOptionPane.showMessageDialog(null, mensaje, "Alerta Prioritaria", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void finalizarExpediente(String id) {
        Expediente ex = searchTree.search(id);
        if (ex != null) {
            ex.setFinalizado(true);
            ex.setFechaFin(LocalDateTime.now());
            registeredExpedients.delete(ex);
            finalizados.Add(ex);
            priorityPendings = rebuildPriorityQueue();

            if (priorityPendings.isEmpty()) {
                alertaTimer.stop();
            }
        }
    }

    private PriorityQueue rebuildPriorityQueue() {
        PriorityQueue nueva = new PriorityQueue();
        Node<Expediente> ptr = registeredExpedients.getNext();

        while (ptr != null) {
            if (ptr.getItem().estaPendiente()) {
                nueva.enqueue(ptr.getItem());
            }
            ptr = ptr.getNext();
        }

        return nueva;
    }

    public Expediente peekPrioritario() {
        limpiarFinalizados();
        return priorityPendings.peek();
    }

    private void limpiarFinalizados() {
        while (!priorityPendings.isEmpty() && priorityPendings.peek().isFinalizado()) {
            priorityPendings.dequeue();
        }
    }

    public void generarArchivoExpediente(Expediente expediente) {
        String nombreArchivo = "Expediente_" + expediente.getId() + ".txt";
        try (PrintWriter writer = new PrintWriter(new FileWriter(nombreArchivo))) {
            writer.println("=== Detalles del Expediente Finalizado ===");
            writer.println("ID: " + expediente.getId());
            writer.println("Nombre: " + expediente.getInteresado().getNombres());
            writer.println("DNI: " + expediente.getInteresado().getDni());
            writer.println("Teléfono: " + expediente.getInteresado().getTelefono());
            writer.println("Asunto: " + expediente.getAsunto());
            writer.println("Estado: " + expediente.getEstado());
            writer.println("Prioridad: " + expediente.getPrioridad());
            writer.println("Dependencia: " + expediente.getDependenciaOrigen());
            writer.println("Fecha de Inicio: " + expediente.getFechaInicio());
            writer.println("Fecha de Fin: " + expediente.getFechaFin());
            writer.println("==========================================");
            
            File archivo = new File(nombreArchivo);
            if (archivo.exists() && Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(archivo);
            }
        } catch (IOException e) {
            System.out.println("Error al generar archivo: " + e.getMessage());
        }
    }
}

