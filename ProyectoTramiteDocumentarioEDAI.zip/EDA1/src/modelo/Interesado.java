package modelo;

public class Interesado {
    private String dni;
    private String nombres;
    private String telefono;
    private String email;
    private boolean esTrabajadorULima;

    public Interesado(String dni, String nombres, String telefono, String email, boolean esTrabajadorULima) {
        this.dni = dni;
        this.nombres = nombres;
        this.telefono = telefono;
        this.email = email;
        this.esTrabajadorULima = esTrabajadorULima;
    }

    public String getDni() { 
        return dni; 
    }
    public String getNombres(){ 
        return nombres; 
    }
    public String getTelefono(){ 
        return telefono; 
    }
    public String getEmail(){ 
        return email; 
    }
    public boolean isEsTrabajadorULima(){ 
        return esTrabajadorULima;
    }

    @Override
    public String toString() {
        return "Interesado{" + "dni=" + dni + ", nombres=" + nombres + ", telefono=" + telefono + ", email=" + email + ", esTrabajadorULima=" + esTrabajadorULima + '}';
    }
    
    
}