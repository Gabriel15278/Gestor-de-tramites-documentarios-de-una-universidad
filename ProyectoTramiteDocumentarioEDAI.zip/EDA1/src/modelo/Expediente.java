package modelo;

import java.time.LocalDateTime;

public class Expediente {
    private String id;
    private String prioridad;
    private Interesado interesado;
    private String asunto;
    private String documentoReferencia;
    private String dependenciaOrigen;
    private LocalDateTime fechaInicio;
    private LocalDateTime fechaFin;
    private boolean finalizado;


    public Expediente(String id, String prioridad, Interesado interesado, String asunto, String documentoReferencia, String dependenciaOrigen) {
        this.id = id;
        this.prioridad = prioridad;
        this.interesado = interesado;
        this.asunto = asunto;
        this.documentoReferencia = documentoReferencia;
        this.dependenciaOrigen = dependenciaOrigen;
        this.fechaInicio = LocalDateTime.now();
        this.finalizado = false;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public Interesado getInteresado() {
        return interesado;
    }

    public void setInteresado(Interesado interesado) {
        this.interesado = interesado;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getDocumentoReferencia() {
        return documentoReferencia;
    }

    public void setDocumentoReferencia(String documentoReferencia) {
        this.documentoReferencia = documentoReferencia;
    }

    public String getDependenciaOrigen() {
        return dependenciaOrigen;
    }

    public void setDependenciaOrigen(String dependenciaOrigen) {
        this.dependenciaOrigen = dependenciaOrigen;
    }

    public LocalDateTime getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDateTime fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDateTime getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDateTime fechaFin) {
        this.fechaFin = fechaFin;
    }
    
    public void finalizarTramite() {
        this.fechaFin = LocalDateTime.now();
    }
    
    public boolean estaPendiente() {
        return !finalizado;
    }
    
    public String getEstado(){
        if (!finalizado) {
            return "En Proceso";
        }
        else{
            return "Terminado";
        }
    }

    public boolean isFinalizado() {
        return finalizado;
    }

    public void setFinalizado(boolean finalizado) {
        this.finalizado = finalizado;
    }
    
    public boolean getEstadofinal() {
        return finalizado;
    }

    @Override
    public String toString() {
        return "Expediente{" + "id=" + id + ", prioridad=" + prioridad + ", interesado=" + interesado + ", asunto=" + asunto + ", documentoReferencia=" + documentoReferencia + ", dependenciaOrigen=" + dependenciaOrigen + ", fechaInicio=" + fechaInicio + ", fechaFin=" + fechaFin + ", finalizado=" + finalizado + '}';
    }   
}