/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tdda;

/**
 *
 * @author Usuario
 */
public class DoublyLinkedList<T> {
    private Node<T> next;
    private Node<T> prev;

    public DoublyLinkedList() {
        this.next = null;
        this.prev = null;
    }

    public boolean isEmpty() {
        return next == null;
    }

    public void addFirst(T value) {
        Node<T> newNode = new Node<>(value);

        if (isEmpty()) {
            next = newNode;
            prev = newNode;
        } 
        else {
            newNode.setNext(next);
            next.setPrev(newNode);
            next = newNode;
        }
    }

    public void addBefore(T value, T ref) {
        if (isEmpty()) {
            System.out.println("Lista vacía, no se puede insertar.");
            return;
        }

        Node<T> ptr = next;
        while (ptr != null && !ptr.getItem().equals(ref)) {
            ptr = ptr.getNext();
        }

        Node<T> newNode = new Node<>(value);

        if (ptr != null) {
            if (ptr.getPrev() != null) {
                Node<T> tmp = ptr.getPrev();
                tmp.setNext(newNode);
                ptr.setPrev(newNode);
                newNode.setNext(ptr);
                newNode.setPrev(tmp);
            } else {
                addFirst(value);
            }
        } else {
            System.out.println("No se encontró el valor de referencia.");
        }
    }

    public void addLast(T value) {
        Node<T> newNode = new Node<>(value);

        if (isEmpty()) {
            next = newNode;
            prev = newNode;
        } 
        else {
            newNode.setPrev(prev);
            prev.setNext(newNode);
            prev = newNode;
        }
    }

    public void showForward() {
        Node<T> ptr = next;

        while (ptr != null) {
            System.out.print(ptr.getItem() + " --> ");
            ptr = ptr.getNext();
        }

        System.out.println("null");
    }

    public void showBehind() {
        Node<T> ptr = prev;

        while (ptr != null) {
            System.out.print(ptr.getItem() + " <-- ");
            ptr = ptr.getPrev();
        }

        System.out.println("null");
    }

    public void delete(T value) {
        if (isEmpty()) {
            System.out.println("La lista está vacía.");
            return;
        }

        Node<T> ptr = next;

        while (ptr != null && !ptr.getItem().equals(value)) {
            ptr = ptr.getNext();
        }

        if (ptr != null) {
            if (ptr == next) {
                next = ptr.getNext();
                if (next != null) next.setPrev(null);
                else prev = null; // si era el único nodo
            } 
            else if (ptr == prev) {
                prev = ptr.getPrev();
                if (prev != null) prev.setNext(null);
                else next = null;
            } 
            else {
                Node<T> tmp = ptr.getPrev();
                tmp.setNext(ptr.getNext());
                ptr.getNext().setPrev(tmp);
            }
        } 
        else {
            System.out.println("No se encontró el elemento a eliminar.");
        }
    }

    public Node<T> search(T value) {
        Node<T> ptr = next;

        while (ptr != null && !ptr.getItem().equals(value)) {
            ptr = ptr.getNext();
        }

        if (ptr != null) {
            return ptr;
        } 
        else {
            System.out.println("No se encontró el elemento en la lista.");
            return null;
        }
    }

    public int countElements() {
        if (isEmpty()) {
            System.out.println("Lista vacía.");
            return 0;
        } 
        else {
            Node<T> ptr = next;
            int count = 0;
            while (ptr != null) {
                count++;
                ptr = ptr.getNext();
            }
            return count;
        }
    }

    public Node<T> getNext() {
        return next;
    }

    public Node<T> getPrev() {
        return prev;
    }
    
}

