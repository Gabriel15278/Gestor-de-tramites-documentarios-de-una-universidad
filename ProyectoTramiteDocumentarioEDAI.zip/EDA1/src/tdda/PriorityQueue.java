package tdda;

import modelo.Expediente;

public class PriorityQueue {
    private Node<Expediente> front;

    public PriorityQueue() {
        front = null;
    }

    public boolean isEmpty() {
        return front == null;
    }

    private int getPriorityLevel(String prioridad) {
        if (prioridad.equalsIgnoreCase("Alta")){ 
            return 1;
        }
        if (prioridad.equalsIgnoreCase("Media")){ 
            return 2;
        }
        return 3;
    }

    public void enqueue(Expediente ex) {
        Node<Expediente> newNode = new Node<>(ex);

        if (front == null || getPriorityLevel(ex.getPrioridad()) < getPriorityLevel(front.getItem().getPrioridad())) {
            newNode.setNext(front);
            front = newNode;
        } else {
            Node<Expediente> current = front;
            while (current.getNext() != null &&
                   getPriorityLevel(ex.getPrioridad()) >= getPriorityLevel(current.getNext().getItem().getPrioridad())) {
                current = current.getNext();
            }
            newNode.setNext(current.getNext());
            current.setNext(newNode);
        }
    }

    public Expediente dequeue() {
        if (!isEmpty()) {
            Expediente ex = front.getItem();
            front = front.getNext();
            return ex;
        }
        return null;
    }

    public Expediente peek() {
        if (isEmpty()) {
            return null;
        } else {
            return front.getItem();
        }
    }
    public int countElements() {
        int count = 0;
        Node<Expediente> temp = front;
        while (temp != null) {
            count++;
            temp = temp.getNext();
        }
        return count;
    }

    public Node<Expediente> getFront() {
        return front;
    }
}
