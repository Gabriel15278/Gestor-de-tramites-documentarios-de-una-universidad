/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tdda;

/**
 *
 * @author galac
 */
public class LinkedList<T> {
    private Node<T> L;

    public LinkedList() {
        this.L = null;
    }

    public void Add(T item) {
        Node<T> nuevo = new Node<>(item);
        if (L == null) {
            L = nuevo;
        } 
        else {
            Node<T> aux = L;
            while (aux.getNext() != null) {
                aux = aux.getNext();
            }
            aux.setNext(nuevo);
        }
    }

    public void showFoward() {
        Node<T> aux = L;
        while (aux != null) {
            System.out.println(aux.getItem());
            aux = aux.getNext();
        }
    }

    public boolean isEmpty() {
        return L == null;
    }

    public Node<T> getNode() {
        return L;
    }
}
