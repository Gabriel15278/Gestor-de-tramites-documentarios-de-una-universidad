package tdda;

public class Stack<T> {
    private Node<T> top;

    public Stack() {
        this.top = null;
    }

    public boolean isEmpty() {
        return top == null;
    }

    public void push(T elemento) {
        Node<T> nuevoNodo = new Node<>(elemento);
        nuevoNodo.setNext(top);
        top = nuevoNodo;
    }

    public T pop() {
        if (!isEmpty()) {
            T elemento = top.getItem();
            top = top.getNext();
            return elemento;
        }
        return null;
    }

    public T top() {
        if (!isEmpty()) {
            return top.getItem();
        }
        return null;
    }

    public int countElements() {
        int count = 0;
        Node<T> aux = top;
        while (aux != null) {
            aux = aux.getNext();
            count++;
        }
        return count;
    }
}
