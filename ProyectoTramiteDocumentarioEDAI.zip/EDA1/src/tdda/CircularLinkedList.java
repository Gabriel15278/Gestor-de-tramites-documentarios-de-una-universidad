/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tdda;

/**
 *
 * @author galac
 */
public class CircularLinkedList<T> {
    private Node<T> L;

    public CircularLinkedList() {
        L = null;
    }

    public Node<T> getL() {
        return L;
    }

    public boolean isEmpty() {
        return L == null;
    }

    public void addFirst(T value) {
        Node<T> newNode = new Node<>(value);

        if (L != null) {
            Node<T> ptr = L;
            while (ptr.getNext() != L) {
                ptr = ptr.getNext();
            }
            newNode.setNext(L);
            ptr.setNext(newNode);
            L = newNode;
        } else {
            L = newNode;
            newNode.setNext(L);
        }
    }

    public void addLast(T value) {
        if (isEmpty()) {
            addFirst(value);
        } else {
            Node<T> newNode = new Node<>(value);
            Node<T> ptr = L;
            while (ptr.getNext() != L) {
                ptr = ptr.getNext();
            }
            ptr.setNext(newNode);
            newNode.setNext(L);
        }
    }

    public void removeFirst() {
        if (!isEmpty()) {
            if (L.getNext() == L) {
                L = null;
            } else {
                Node<T> ptr = L;
                while (ptr.getNext() != L) {
                    ptr = ptr.getNext();
                }
                L = L.getNext();
                ptr.setNext(L);
            }
        }
    }

    public void showElements() {
        if (isEmpty()) {
            System.out.println("Empty list");
            return;
        }

        Node<T> ptr = L;
        do {
            System.out.print(ptr.getItem() + " --> ");
            ptr = ptr.getNext();
        } while (ptr != L);
        System.out.println("(back to start)");
    }

    public int indexOf(T item) {
        if (isEmpty()) return -1;

        Node<T> ptr = L;
        int count = 0;
        do {
            if (ptr.getItem().equals(item)) {
                return count;
            }
            ptr = ptr.getNext();
            count++;
        } while (ptr != L);

        return -1;
    }

    public void remove(T item) {
        if (isEmpty()) return;

        Node<T> ptr = L;
        Node<T> prev = null;

        do {
            if (ptr.getItem().equals(item)) {
                if (ptr == L) {
                    if (L.getNext() == L) {
                        L = null;
                    } else {
                        Node<T> tail = L;
                        while (tail.getNext() != L) {
                            tail = tail.getNext();
                        }
                        L = L.getNext();
                        tail.setNext(L);
                    }
                } else {
                    prev.setNext(ptr.getNext());
                }
                return;
            }
            prev = ptr;
            ptr = ptr.getNext();
        } while (ptr != L);
    }

    public int countElements() {
        if (isEmpty()) return 0;

        int count = 0;
        Node<T> ptr = L;
        do {
            count++;
            ptr = ptr.getNext();
        } while (ptr != L);

        return count;
    }

    public void addAfterIndex(T value, int index) {
        if (isEmpty()) {
            Node<T> newNode = new Node<>(value);
            L = newNode;
            newNode.setNext(L);
            return;
        }

        Node<T> ptr = L;
        int count = 0;

        do {
            if (count == index) {
                Node<T> newNode = new Node<>(value);
                newNode.setNext(ptr.getNext());
                ptr.setNext(newNode);
                return;
            }
            ptr = ptr.getNext();
            count++;
        } while (ptr != L);

        System.out.println("Index out of bounds");
    }
}

