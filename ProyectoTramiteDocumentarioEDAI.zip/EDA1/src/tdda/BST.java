/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tdda;

import modelo.Expediente;

/**
 *
 * @author galac
 */
public class BST {
    private Node<Expediente> root;

    public void insert(Expediente expediente) {
        root = insertRecursive(root, expediente);
    }

    private Node<Expediente> insertRecursive(Node<Expediente> current, Expediente expediente) {
        if (current == null) {
            return new Node<>(expediente);
        }

        String newId = expediente.getId();
        String currentId = current.getItem().getId();

        if (newId.compareTo(currentId) < 0) {
            Node<Expediente> left = insertRecursive(current.getPrev(), expediente);
            current.setPrev(left);
        } else {
            Node<Expediente> right = insertRecursive(current.getNext(), expediente);
            current.setNext(right);
        }

        return current;
    }

    public Expediente search(String id) {
        return searchRecursive(root, id);
    }

    private Expediente searchRecursive(Node<Expediente> current, String id) {
        if (current == null) {
            return null;
        }
        String currentId = current.getItem().getId();

        if (id.equals(currentId)) {
            return current.getItem();
        }
        if (id.compareTo(currentId) < 0) {
            return searchRecursive(current.getPrev(), id);
        } 
        else {
            return searchRecursive(current.getNext(), id);
        }
    }

    public void printInOrder() {
        printInOrderRecursive(root);
    }

    private void printInOrderRecursive(Node<Expediente> current) {
        if (current != null) {
            printInOrderRecursive(current.getPrev());
            System.out.println(current.getItem());
            printInOrderRecursive(current.getNext());        }
    }
}
